import { createSlice } from "@reduxjs/toolkit";


let userSngleDataSlice = createSlice({
    name:'edituser',
    initialState:{data:null},
    reducers:{
        addData(state,action){
            state.data = action.payload
        }
    }
})

export  const {addData} = userSngleDataSlice.actions
export const editReducer = userSngleDataSlice.reducer