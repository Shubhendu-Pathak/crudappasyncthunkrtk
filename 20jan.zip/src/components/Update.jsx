import React, { useState } from 'react'
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';
import { useLocation } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { putusers } from '../store/thunk/fetchUsers';



function Update() {

    let getsingleData = useSelector(state=>state.editdata.data)
    console.log(getsingleData);

    let[val,setval]=useState({
        username:'',
        myemail:'',
        mypass:''
    })

console.log(val);

    let handleChange=(e)=>{
        setval(
            {...val,[e.target.name]:e.target.value}
        )
    }

let dispatch =useDispatch()

let handleSubmit=(e)=>{
  e.preventDefault(0)
dispatch(putusers(getsingleData.id,val))
}

  return (
    <Form onSubmit={handleSubmit} className='bg-info p-4'>
        <h1 className='text-bg-danger'>UPDATE DATA</h1>
        <hr />
    <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
    <Form.Group className="mb-3" controlId="exampleForm.ControlTextarea1">
      <Form.Label>Username</Form.Label>
      <Form.Control
       type="text" 
       placeholder="username..." 
       name='username'
       value={val.username}
       onChange={handleChange}
       />
    </Form.Group>
      <Form.Label>Email address</Form.Label>
      <Form.Control
       type="email" 
       placeholder="name@example.com"
       value={val.myemail}
       name='myemail'
       onChange={handleChange}
       />
    </Form.Group>
    <Form.Group className="mb-3" controlId="exampleForm.ControlTextarea1">
      <Form.Label>password</Form.Label>
      <Form.Control 
      type="text" 
      placeholder="password"
      value={val.mypass}
      name='mypass'
      onChange={handleChange}
      />
    </Form.Group>
    <Button type='submit'>Submit</Button>
  </Form>
  )
}

export default Update